import "server-only";

const owner = process.env.GITHUB_OWNER || "vinod-rajput-vg";
const repo = process.env.GITHUB_REPO || "My-India-TV";
const branch = process.env.GITHUB_BRANCH || "main";
const apiRoot = `https://api.github.com/repos/${owner}/${repo}/contents`;

function headers() {
  const token = process.env.GITHUB_TOKEN;
  if (!token) throw new Error("GITHUB_TOKEN is not configured on the server.");
  return { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "Content-Type": "application/json" };
}

export async function readTextFile(path: string): Promise<{ text: string; sha: string }> {
  const response = await fetch(`${apiRoot}/${path.split("/").map(encodeURIComponent).join("/")}?ref=${encodeURIComponent(branch)}`, { headers: headers(), cache: "no-store" });
  if (!response.ok) throw new Error(`GitHub read failed for ${path} (${response.status}).`);
  const data = await response.json();
  if (data.type !== "file" || typeof data.content !== "string") throw new Error(`GitHub path is not a text file: ${path}`);
  return { text: Buffer.from(data.content.replace(/\n/g, ""), "base64").toString("utf8"), sha: data.sha };
}

export async function writeTextFile(path: string, content: string, message: string) {
  const current = await readTextFile(path);
  const response = await fetch(`${apiRoot}/${path.split("/").map(encodeURIComponent).join("/")}`, {
    method: "PUT", headers: headers(),
    body: JSON.stringify({ message, content: Buffer.from(content, "utf8").toString("base64"), sha: current.sha, branch })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 409 || response.status === 422) throw new Error("GitHub file changed concurrently or the update conflicted. Reload the catalog and try again.");
    throw new Error(data.message || `GitHub write failed (${response.status}).`);
  }
  return { commit: data.commit?.html_url as string | undefined, sha: data.content?.sha as string | undefined };
}

export const REPO_URL = `https://github.com/${owner}/${repo}`;
