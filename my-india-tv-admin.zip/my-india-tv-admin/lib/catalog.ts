export type Channel = { name: string; logoUrl: string; streamUrl: string };
export type Category = { slug: string; label: string; iconUrl: string; channelsPath: string };

const CHANNEL_BASE = "Category Channels";
const ICON_BASE = "Category Icons";
const RAW_BASE = "https://raw.githubusercontent.com/vinod-rajput-vg/My-India-TV/main";

export function slugify(input: string) {
  return input.trim().toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
export function safeSlug(slug: string) {
  return /^[a-z0-9][a-z0-9-]{0,49}$/.test(slug);
}
export function parseCategories(text: string): Category[] {
  const blocks = text.trim().split(/\n\s*\n/).map(x => x.trim()).filter(Boolean);
  return blocks.map(block => {
    const lines = block.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    if (lines.length < 3) return null;
    const iconUrl = lines[1];
    const path = decodeURIComponent(lines[2].split("/main/")[1] || "");
    const filename = path.split("/").pop() || `${lines[0]}.txt`;
    const slug = filename.replace(/\.txt$/i, "");
    return { slug, label: lines[0].split(/[-_]/g).map(w => w ? w[0].toUpperCase()+w.slice(1) : "").join(" "), iconUrl, channelsPath: path || `${CHANNEL_BASE}/${slug}.txt` };
  }).filter((x): x is Category => Boolean(x));
}
export function serializeCategories(categories: Category[]) {
  return categories.map(c => `${c.label.trim()}\n${c.iconUrl.trim()}\n${RAW_BASE}/${encodeURI(c.channelsPath).replace(/#/g, "%23")}`).join("\n\n") + "\n";
}
export function parseChannels(text: string): Channel[] {
  const lines = text.replace(/\r/g, "").split("\n");
  const records: string[][] = [];
  let current: string[] = [];
  for (const line of lines) {
    if (!line.trim()) { if (current.length) { records.push(current); current = []; } }
    else current.push(line.trim());
  }
  if (current.length) records.push(current);
  return records.filter(r => r.length >= 3).map(r => ({ name: r[0], logoUrl: r[1], streamUrl: r.slice(2).join("\n") }));
}
export function serializeChannels(channels: Channel[]) {
  return channels.map(c => `${c.name.trim()}\n${c.logoUrl.trim()}\n${c.streamUrl.trim()}`).join("\n\n") + (channels.length ? "\n" : "");
}
export function validateChannels(channels: Channel[]) {
  if (!Array.isArray(channels)) throw new Error("Channels must be a list.");
  for (const [i, c] of channels.entries()) {
    if (!c.name?.trim() || !isHttpUrl(c.logoUrl) || !isHttpUrl(c.streamUrl)) throw new Error(`Channel ${i+1}: name, a valid HTTP(S) logo URL and a valid HTTP(S) stream URL are required.`);
    if (c.name.includes("\n") || c.logoUrl.includes("\n") || c.streamUrl.includes("\n")) throw new Error(`Channel ${i+1}: fields must each be a single line.`);
  }
}
export function isHttpUrl(value: string) {
  try { const u = new URL(value); return u.protocol === "https:" || u.protocol === "http:"; } catch { return false; }
}
export function categoryPaths(slug: string) {
  return { channelsPath: `${CHANNEL_BASE}/${slug}.txt`, iconPath: `${ICON_BASE}/${slug}.png` };
}
