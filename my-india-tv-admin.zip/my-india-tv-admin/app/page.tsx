"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, type User } from "firebase/auth";
import { auth } from "@/lib/firebase-client";
import type { Category, Channel } from "@/lib/catalog";

type Catalog = { categories: Category[]; channelsBySlug: Record<string, Channel[]>; repoUrl: string };
const emptyChannel = (): Channel => ({ name: "", logoUrl: "", streamUrl: "" });

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [activeSlug, setActiveSlug] = useState("");
  const [query, setQuery] = useState("");
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [selectedIndices, setSelectedIndices] = useState<number[]>([]);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const channelSaveInFlight = useRef(false);
  const [editChannel, setEditChannel] = useState<Channel | null>(null);
  const [editIndex, setEditIndex] = useState<number | null>(null);
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [categoryDraft, setCategoryDraft] = useState({ label: "", slug: "", iconUrl: "" });

  useEffect(() => onAuthStateChanged(auth, u => { setUser(u); setAuthReady(true); }), []);
  const api = useCallback(async (path: string, options: RequestInit = {}) => {
    if (!user) throw new Error("Please sign in first.");
    const token = await user.getIdToken();
    const response = await fetch(path, { ...options, headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...(options.headers || {}) } });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status}).`);
    return data;
  }, [user]);
  const loadCatalog = useCallback(async () => {
    setBusy(true); setError(""); setNotice("");
    try { const data = await api("/api/catalog"); setCatalog(data); setActiveSlug((old: string) => data.categories.some((c: Category) => c.slug === old) ? old : data.categories[0]?.slug || ""); }
    catch (e) { setError(e instanceof Error ? e.message : "Unable to load catalog."); }
    finally { setBusy(false); }
  }, [api]);
  useEffect(() => { if (user) void loadCatalog(); else setCatalog(null); }, [user, loadCatalog]);
  const activeCategory = catalog?.categories.find(c => c.slug === activeSlug);
  const channels = useMemo(() => catalog?.channelsBySlug[activeSlug] || [], [catalog, activeSlug]);
  const filteredChannels = useMemo(() => {
    const items = channels
      .map((channel, index) => ({ channel, index }))
      .filter(({ channel }) => `${channel.name} ${channel.logoUrl} ${channel.streamUrl}`.toLowerCase().includes(query.toLowerCase()));
    // Keep the exact order stored in the category TXT file.
    return items;
  }, [channels, query]);
  const visibleIndices = filteredChannels.map(({ index }) => index);
  const allVisibleSelected = visibleIndices.length > 0 && visibleIndices.every(index => selectedIndices.includes(index));
  function toggleSelected(index: number) {
    setSelectedIndices(current => current.includes(index) ? current.filter(item => item !== index) : [...current, index]);
  }
  function moveChannel(fromIndex: number, toIndex: number) {
    if (query.trim() || fromIndex === toIndex || fromIndex < 0 || toIndex < 0 || fromIndex >= channels.length || toIndex >= channels.length) return;
    const next = [...channels];
    const [moved] = next.splice(fromIndex, 1);
    next.splice(toIndex, 0, moved);
    setDraggedIndex(null);
    void saveChannels(next, "Channel order updated.");
  }
  function toggleSelectVisible() {
    setSelectedIndices(current => allVisibleSelected
      ? current.filter(index => !visibleIndices.includes(index))
      : Array.from(new Set([...current, ...visibleIndices])));
  }
  function deleteSelected() {
    const selected = selectedIndices.filter(index => index >= 0 && index < channels.length);
    if (!selected.length) return;
    if (!confirm(`Delete ${selected.length} selected channel${selected.length === 1 ? "" : "s"}? This will create a GitHub commit.`)) return;
    const next = channels.filter((_, index) => !selected.includes(index));
    void saveChannels(next, `${selected.length} selected channel${selected.length === 1 ? "" : "s"} deleted.`);
    setSelectedIndices([]);
  }

  async function saveChannels(next: Channel[], success: string) {
    if (!activeCategory || channelSaveInFlight.current) return;

    const slug = activeSlug;
    const previousCatalog = catalog;
    if (!previousCatalog) return;

    // Apply the change immediately in the UI, preserving the TXT array order.
    const optimisticCatalog: Catalog = {
      ...previousCatalog,
      channelsBySlug: { ...previousCatalog.channelsBySlug, [slug]: next },
    };
    setCatalog(optimisticCatalog);
    setError("");
    setNotice("Changes shown locally. Saving to GitHub…");
    channelSaveInFlight.current = true;
    setBusy(true);

    try {
      const data = await api("/api/save", {
        method: "POST",
        body: JSON.stringify({ type: "channels", slug, channels: next }),
      });
      if (!data?.ok) throw new Error("GitHub did not confirm the save.");
      setNotice(`${success} GitHub commit created.`);
      setEditChannel(null);
      setEditIndex(null);
      setSelectedIndices([]);
    } catch (saveError) {
      // Full catalog refresh is reserved for failed/ambiguous saves.
      try {
        const refreshed = await api("/api/catalog");
        const actualChannels = refreshed.channelsBySlug?.[slug] || [];
        setCatalog(refreshed);
        const same = actualChannels.length === next.length && actualChannels.every((channel: Channel, index: number) =>
          channel.name === next[index]?.name &&
          channel.logoUrl === next[index]?.logoUrl &&
          channel.streamUrl === next[index]?.streamUrl
        );
        if (same) {
          setNotice(`${success} GitHub update confirmed after reconnecting.`);
          setError("");
          setEditChannel(null);
          setEditIndex(null);
          setSelectedIndices([]);
        } else {
          setError(`${saveError instanceof Error ? saveError.message : "Save request failed."} Your latest catalog was reloaded; check GitHub before retrying.`);
          setNotice("");
        }
      } catch (refreshError) {
        setError(`${saveError instanceof Error ? saveError.message : "Save request failed."} Could not verify the GitHub result (${refreshError instanceof Error ? refreshError.message : "refresh failed"}). Refresh before retrying.`);
        setNotice("");
      }
    } finally {
      channelSaveInFlight.current = false;
      setBusy(false);
    }
  }
  async function saveCategory() {
    setBusy(true); setError(""); setNotice("");
    try { const data = await api("/api/categories", { method: "POST", body: JSON.stringify({ action: "upsert", category: categoryDraft }) }); setCatalog(data.catalog); setActiveSlug(data.slug); setShowCategoryForm(false); setCategoryDraft({label:"",slug:"",iconUrl:""}); setNotice("Category saved to GitHub."); }
    catch(e) { setError(e instanceof Error ? e.message : "Category save failed."); }
    finally { setBusy(false); }
  }
  async function removeCategory() {
    if (!activeCategory || !confirm(`Remove category “${activeCategory.label}” from the app catalog? Its TXT file will remain in GitHub as a backup.`)) return;
    setBusy(true); setError(""); setNotice("");
    try { const data = await api("/api/categories", { method: "POST", body: JSON.stringify({ action: "delete", slug: activeSlug }) }); setCatalog(data.catalog); setActiveSlug(data.catalog.categories[0]?.slug || ""); setNotice("Category removed from categories.txt. The TXT file was kept as a backup."); }
    catch(e) { setError(e instanceof Error ? e.message : "Delete failed."); }
    finally { setBusy(false); }
  }
  async function handleLogin(e: React.FormEvent) { e.preventDefault(); setError(""); setBusy(true); try { await signInWithEmailAndPassword(auth, email.trim(), password); setPassword(""); } catch(e) { setError(e instanceof Error ? e.message : "Login failed."); } finally { setBusy(false); } }

  if (!authReady) return <main className="center-screen"><div className="login-card"><p className="eyebrow">MY INDIA TV</p><h1>Admin Panel</h1><p>Checking authentication…</p></div></main>;
  if (!user) return <main className="center-screen"><form className="login-card" onSubmit={handleLogin}><p className="eyebrow">MY INDIA TV / CATALOG</p><h1>Admin Panel</h1><p className="muted">Sign in with the Firebase account added to <code>ADMIN_EMAILS</code>.</p><label>Email<input type="email" autoComplete="username" required value={email} onChange={e=>setEmail(e.target.value)} /></label><label>Password<input type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)} /></label>{error && <div className="alert error">{error}</div>}<button className="primary full" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button><p className="small muted">Accounts must be created in Firebase Console. Public sign-up is not provided.</p></form></main>;

  return <main className="app-shell">
    <header className="topbar"><div><p className="eyebrow">MY INDIA TV</p><h1>Admin Panel</h1></div><div className="user-tools"><span className="user-email">{user.email}</span><button className="secondary" onClick={()=>void loadCatalog()} disabled={busy}>Refresh</button><button className="secondary" onClick={()=>void signOut(auth)}>Sign out</button></div></header>
    {error && <div className="alert error">{error}</div>}{notice && <div className="alert success">{notice}</div>}
    <div className="workspace"><aside className="sidebar"><div className="section-heading"><h2>Categories</h2><button className="icon-button" title="Add category" onClick={()=>{setCategoryDraft({label:"",slug:"",iconUrl:""});setShowCategoryForm(true)}}>＋</button></div>
      <div className="category-list">{catalog?.categories.map(c=><button key={c.slug} className={`category-item ${activeSlug===c.slug?"selected":""}`} onClick={()=>{setActiveSlug(c.slug);setQuery("");setEditChannel(null);setEditIndex(null);setSelectedIndices([])}}><span className="category-dot">{c.label.slice(0,1).toUpperCase()}</span><span><strong>{c.label}</strong><small>{catalog.channelsBySlug[c.slug]?.length || 0} channels</small></span><span className="chevron">›</span></button>)}</div>
    </aside><section className="content-panel">
      {activeCategory ? <><div className="content-heading"><div><p className="eyebrow">CATEGORY FILE</p><h2>{activeCategory.label}</h2><code className="path">{activeCategory.channelsPath}</code></div><div className="heading-actions"><button className="secondary" onClick={()=>{setCategoryDraft({label:activeCategory.label,slug:activeCategory.slug,iconUrl:activeCategory.iconUrl});setShowCategoryForm(true)}}>Edit category</button><button className="danger-outline" onClick={()=>void removeCategory()} disabled={busy}>Remove</button></div></div>
      <div className="toolbar" style={{ gap: 10, flexWrap: "wrap" }}>
        <div className="search-box" style={{ flex: "1 1 240px" }}><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search channel name or URL…" /></div>
        <button className="primary" onClick={()=>{setEditIndex(null);setEditChannel(emptyChannel())}}>＋ Add channel</button>
      </div>
      {query.trim() && <p className="muted" style={{ fontSize: 12, margin: "0 0 10px" }}>Clear search to enable drag-and-drop reordering.</p>}
      {filteredChannels.length > 0 && <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap", margin: "8px 0 14px", padding: "11px 14px", border: "1px solid var(--border, #2b3445)", borderRadius: 14, background: "var(--surface, #111722)" }}>
        <label style={{ display: "inline-flex", alignItems: "center", gap: 10, cursor: "pointer", fontSize: 13, color: "var(--muted, #aab4c5)" }}><input type="checkbox" checked={allVisibleSelected} onChange={toggleSelectVisible} aria-label="Select all visible channels" style={{ width: 17, height: 17, accentColor: "#526dff" }} /></label>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}><span style={{ fontSize: 13, color: "var(--muted, #aab4c5)" }}>{selectedIndices.length} selected</span>{selectedIndices.length > 0 && <button className="danger-outline compact" disabled={busy} onClick={deleteSelected}>Delete selected</button>}</div>
      </div>}
      {editChannel && <div className="editor-card"><div className="section-heading"><h3>{editIndex===null?"Add channel":"Edit channel"}</h3><button className="text-button" onClick={()=>{setEditChannel(null);setEditIndex(null)}}>Cancel</button></div><div className="form-grid"><label>Channel name<input value={editChannel.name} onChange={e=>setEditChannel({...editChannel,name:e.target.value})} placeholder="e.g. News Channel HD" /></label><label>Logo URL<input value={editChannel.logoUrl} onChange={e=>setEditChannel({...editChannel,logoUrl:e.target.value})} placeholder="https://…/logo.png" /></label><label className="wide">Stream URL<input value={editChannel.streamUrl} onChange={e=>setEditChannel({...editChannel,streamUrl:e.target.value})} placeholder="https://…/index.m3u8" /></label></div><div className="editor-actions"><span className="small muted">All fields are required. HTTP(S) URLs accepted.</span><button className="primary" disabled={busy} onClick={()=>{const next=[...channels]; if(editIndex===null) next.push(editChannel); else next[editIndex]=editChannel; void saveChannels(next,editIndex===null?"Channel added.":"Channel updated.")}}>{busy?"Saving…":"Save to GitHub"}</button></div></div>}
      <div className="channel-list">{filteredChannels.map(({channel,index})=><article className="channel-row" key={`${channel.name}-${index}`} onDragOver={e=>{if(!query.trim() && draggedIndex!==null){e.preventDefault();}}} onDrop={e=>{e.preventDefault();if(draggedIndex!==null)moveChannel(draggedIndex,index);}} style={{ outline: draggedIndex===index ? "1px dashed #8796ff" : undefined, opacity: draggedIndex===index ? 0.65 : 1 }}><label title="Select channel" style={{ display: "flex", alignItems: "center", padding: "0 4px", cursor: "pointer" }}><input type="checkbox" checked={selectedIndices.includes(index)} onChange={()=>toggleSelected(index)} onClick={e=>e.stopPropagation()} aria-label={`Select ${channel.name}`} style={{ width: 17, height: 17, accentColor: "#526dff" }} /></label><div className="channel-logo">{channel.logoUrl ? <Image src={channel.logoUrl} alt="" width={64} height={64} unoptimized onError={e=>{e.currentTarget.style.display="none"}}/> : <span>{channel.name.slice(0,1)}</span>}</div><div className="channel-info"><strong>{channel.name}</strong><span title={channel.logoUrl}>Logo: {channel.logoUrl}</span><span title={channel.streamUrl}>Stream: {channel.streamUrl}</span></div><div className="row-actions"><button className="secondary compact" disabled={busy} onClick={()=>{setEditIndex(index);setEditChannel({...channel})}}>Edit</button><button className="danger-outline compact" disabled={busy} onClick={()=>{if(confirm(`Delete ${channel.name}?`)) void saveChannels(channels.filter((_,i)=>i!==index),"Channel deleted.")}}>Delete</button><button type="button" className="secondary compact" draggable={!busy && !query.trim()} title={query.trim()?"Clear search to reorder channels":"Drag to reorder channel"} aria-label={`Drag to reorder ${channel.name}`} disabled={busy || !!query.trim()} onDragStart={e=>{e.dataTransfer.effectAllowed="move";e.dataTransfer.setData("text/plain",String(index));setDraggedIndex(index);}} onDragEnd={()=>setDraggedIndex(null)} style={{ width: 34, minWidth: 34, padding: "6px 8px", cursor: query.trim()?"not-allowed":"grab", display:"inline-flex", alignItems:"center", justifyContent:"center" }}><span aria-hidden="true" style={{ display:"flex", flexDirection:"column", gap:3 }}><span style={{display:"block",width:14,height:2,borderRadius:2,background:"currentColor"}}/><span style={{display:"block",width:14,height:2,borderRadius:2,background:"currentColor"}}/></span></button></div></article>)}
        {!filteredChannels.length && <div className="empty-state"><div className="empty-icon">⌕</div><h3>{query?"No matching channels":"No channels yet"}</h3><p>{query?"Try a different search term.":"Add the first channel to this category."}</p>{!query && <button className="primary" onClick={()=>setEditChannel(emptyChannel())}>Add channel</button>}</div>}</div>
      </> : <div className="empty-state"><h2>No category selected</h2><p>Add a category to get started.</p><button className="primary" onClick={()=>setShowCategoryForm(true)}>Add category</button></div>}
    </section></div>
    {showCategoryForm && <div className="modal-backdrop" role="presentation"><form className="modal" onSubmit={e=>{e.preventDefault();void saveCategory()}}><div className="section-heading"><div><p className="eyebrow">CATEGORY CONFIGURATION</p><h2>{catalog?.categories.some(c=>c.slug===categoryDraft.slug)?"Edit category":"Add category"}</h2></div><button type="button" className="icon-button" onClick={()=>setShowCategoryForm(false)}>×</button></div><label>Display name<input required value={categoryDraft.label} onChange={e=>setCategoryDraft({...categoryDraft,label:e.target.value,slug:categoryDraft.slug || e.target.value.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")})} placeholder="Entertainment" /></label><label>File slug<input required pattern="[a-z0-9][a-z0-9-]{0,49}" value={categoryDraft.slug} onChange={e=>setCategoryDraft({...categoryDraft,slug:e.target.value})} placeholder="entertainment" /><small className="muted">Lowercase letters, numbers and hyphens only. Existing slugs must not be changed because the app uses their TXT paths.</small></label><label>Category icon URL<input type="url" required value={categoryDraft.iconUrl} onChange={e=>setCategoryDraft({...categoryDraft,iconUrl:e.target.value})} placeholder="https://…/category.png" /></label><div className="alert info">New categories use <code>Category Channels/{categoryDraft.slug || "slug"}.txt</code>. For a new category, create an empty TXT file at that path in GitHub first, then save the category. This keeps all existing Android paths unchanged.</div><div className="modal-actions"><button type="button" className="secondary" onClick={()=>setShowCategoryForm(false)}>Cancel</button><button className="primary" disabled={busy}>{busy?"Saving…":"Save category"}</button></div></form></div>}
  </main>;
}
