import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/firebase-admin";
import { readTextFile, writeTextFile } from "@/lib/github";
import { parseCategories, serializeChannels, validateChannels, safeSlug } from "@/lib/catalog";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    await requireAdmin(request);
    const body = await request.json();

    if (body.type !== "channels" || typeof body.slug !== "string" || !safeSlug(body.slug)) {
      throw new Error("Invalid save request.");
    }

    // Read only category metadata to validate the allowlisted TXT path.
    const { text: config } = await readTextFile("Categories/categories.txt");
    const categories = parseCategories(config);
    const category = categories.find(c => c.slug === body.slug);
    if (!category || category.channelsPath !== `Category Channels/${body.slug}.txt`) {
      throw new Error("Category path is not allowlisted.");
    }

    validateChannels(body.channels);
    // writeTextFile performs the GitHub write/commit. Do not reread every category
    // after saving; the client already has the exact channel array it submitted.
    const result = await writeTextFile(
      category.channelsPath,
      serializeChannels(body.channels),
      `Admin: update ${body.slug} channels`
    );

    return NextResponse.json({
      ok: true,
      slug: body.slug,
      channels: body.channels,
      commit: result.commit,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Unable to save channels." },
      { status: 400 }
    );
  }
}
