import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/firebase-admin";
import { readTextFile, REPO_URL } from "@/lib/github";
import { parseCategories, parseChannels } from "@/lib/catalog";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  try {
    await requireAdmin(request);
    const { text } = await readTextFile("Categories/categories.txt");
    const categories = parseCategories(text);
    if (!categories.length) throw new Error("No valid categories found in Categories/categories.txt.");
    const channelsBySlug: Record<string, ReturnType<typeof parseChannels>> = {};
    const results = await Promise.all(categories.map(async c => ({ slug: c.slug, channels: parseChannels((await readTextFile(c.channelsPath)).text) })));
    for (const r of results) channelsBySlug[r.slug] = r.channels;
    return NextResponse.json({ categories, channelsBySlug, repoUrl: REPO_URL }, { headers: { "Cache-Control": "no-store" } });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Unable to load catalog." }, { status: 401 }); }
}
