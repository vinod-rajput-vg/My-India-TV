import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/firebase-admin";
import { readTextFile, writeTextFile, REPO_URL } from "@/lib/github";
import { parseCategories, parseChannels, serializeCategories, safeSlug, slugify, isHttpUrl, categoryPaths } from "@/lib/catalog";
export const runtime = "nodejs";
async function loadCatalog() {
  const {text} = await readTextFile("Categories/categories.txt");
  const categories = parseCategories(text);
  const channelFiles = await Promise.all(categories.map(async c => ({ slug: c.slug, text: (await readTextFile(c.channelsPath)).text })));
  const channelsBySlug: Record<string, ReturnType<typeof parseChannels>> = {};
  for (const file of channelFiles) channelsBySlug[file.slug] = parseChannels(file.text);
  return {categories, channelsBySlug, repoUrl: REPO_URL};
}
export async function POST(request: Request) {
  try {
    await requireAdmin(request);
    const body = await request.json();
    const {text} = await readTextFile("Categories/categories.txt");
    const categories = parseCategories(text);
    if (body.action === "upsert") {
      const label = String(body.category?.label || "").trim();
      const slug = String(body.category?.slug || slugify(label));
      const iconUrl = String(body.category?.iconUrl || "").trim();
      if (!label || label.includes("\n") || !safeSlug(slug) || !isHttpUrl(iconUrl)) throw new Error("Enter a category name, valid slug and HTTP(S) icon URL.");
      const existing = categories.find(c => c.slug === slug);
      if (existing) {
        if (existing.channelsPath !== `Category Channels/${slug}.txt`) throw new Error("This category has a non-standard path; editing it here is blocked to protect the Android app configuration.");
        existing.label = label; existing.iconUrl = iconUrl;
      } else {
        // Category config must only point to the existing app's standard channel-file layout.
        const path = categoryPaths(slug).channelsPath;
        try { await readTextFile(path); } catch { throw new Error(`Create ${path} in GitHub first (an empty file is fine), then add this category.`); }
        categories.push({slug, label, iconUrl, channelsPath: path});
      }
    } else if (body.action === "delete") {
      const slug = String(body.slug || "");
      if (!safeSlug(slug) || !categories.some(c=>c.slug===slug)) throw new Error("Category not found.");
      if (categories.length < 2) throw new Error("At least one category must remain.");
      categories.splice(categories.findIndex(c=>c.slug===slug),1);
    } else throw new Error("Unknown category action.");
    await writeTextFile("Categories/categories.txt", serializeCategories(categories), `Admin: ${body.action} category configuration`);
    const catalog = await loadCatalog();
    return NextResponse.json({ok:true, slug: body.category?.slug || slugify(body.category?.label || ""), catalog});
  } catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Unable to save categories."},{status:400}); }
}
