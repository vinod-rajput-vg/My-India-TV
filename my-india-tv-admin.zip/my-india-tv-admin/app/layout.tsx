import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "My India TV — Admin", description: "Secure channel and category catalog manager" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
