# My India TV Admin Panel

A Next.js admin dashboard for managing the channel catalog in `vinod-rajput-vg/My-India-TV`. It edits the existing GitHub TXT files using the GitHub Contents API, so the Android app keeps reading the same raw GitHub URLs and formats.

## What it does

- Firebase Email/Password sign-in; no public registration screen.
- Server-side Firebase ID-token verification and an `ADMIN_EMAILS` allowlist.
- Browse categories and channels, search channel names/URLs, preview logo images, add/edit/delete channels.
- Edit category label/icon URL and add/remove category entries in `Categories/categories.txt`.
- Saves each change as a GitHub commit. GitHub is the persistent source of truth.
- GitHub write token is read only by server code and is never sent to the browser.

## Repository paths preserved

- `Categories/categories.txt`
- `Category Channels/entertainment.txt`
- `Category Channels/infotainment.txt`
- `Category Channels/news.txt`
- `Category Channels/music.txt`
- `Category Channels/kids.txt`
- `Category Channels/drama.txt`
- `Category Channels/sports.txt`
- `Category Channels/movies.txt`

Channel TXT format remains three lines per record separated by a blank line:

```text
Channel name
https://example.com/logo.png
https://example.com/stream.m3u8

Another channel
https://example.com/logo2.png
https://example.com/stream2.m3u8
```

Category config format remains three lines per record separated by a blank line: category slug, category icon URL, raw GitHub URL of its channel TXT file.

## 1. Create Firebase project

1. Open https://console.firebase.google.com/ and create/select a project.
2. In **Authentication → Sign-in method**, enable **Email/Password**.
3. In **Authentication → Users**, add an account for each trusted admin. Do not enable open/public sign-up.
4. In **Project settings → General → Your apps**, add a Web app and copy its web config.
5. In **Project settings → Service accounts**, generate a private key for the Firebase Admin SDK. Keep this JSON private; never commit it.

## 2. Create a GitHub fine-grained token

1. Open https://github.com/settings/personal-access-tokens/new
2. Select **Only select repositories** → `vinod-rajput-vg/My-India-TV`.
3. Grant **Repository permissions → Contents: Read and write**. No other permission is needed for this app.
4. Copy the token once. Do not place it in a `NEXT_PUBLIC_*` variable or frontend code.

## 3. Configure environment variables

Copy `.env.example` to `.env.local` for local development and fill these values:

- `NEXT_PUBLIC_FIREBASE_API_KEY`, `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`, `NEXT_PUBLIC_FIREBASE_PROJECT_ID`, `NEXT_PUBLIC_FIREBASE_APP_ID`: values from Firebase Web app config.
- `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`: values from the service-account JSON (`private_key` should be stored with newline characters escaped as `\n`).
- `ADMIN_EMAILS`: comma-separated list of the exact Firebase user emails authorized to edit.
- `GITHUB_TOKEN`: fine-grained token.
- `GITHUB_OWNER=vinod-rajput-vg`, `GITHUB_REPO=My-India-TV`, `GITHUB_BRANCH=main`.

Do not commit `.env.local`, service-account JSON, or the GitHub token. On Vercel, add the same variables in **Project → Settings → Environment Variables** for Production (and Preview only if you intentionally want a preview deployment to write to the live repo).

## 4. Run locally

Requires Node.js 20.9+ (Node 22 LTS recommended).

```bash
npm install
cp .env.example .env.local
# Edit .env.local with your values
npm run dev
```

Open http://localhost:3000 and sign in using an admin user created in Firebase Console. Before testing writes, consider using a temporary branch/repository. The default target branch is `main`.

Build check:

```bash
npm run build
```

## 5. Deploy to Vercel Hobby

1. Push this folder to a **separate** GitHub repository (recommended name: `my-india-tv-admin`). Do not overwrite the Android app repository with the web app.
2. In https://vercel.com/new, import the admin-panel repository.
3. Framework should be detected as Next.js. Leave build command as `next build`.
4. Add all environment variables from `.env.example` in Project Settings → Environment Variables.
5. Deploy, then open the production URL and sign in.
6. Verify only the trusted Firebase email is in `ADMIN_EMAILS`. Do not expose a writable preview deployment to untrusted people.

Vercel Hobby is intended for personal/non-commercial use; check current Vercel plan terms and limits for your use case.

## 6. Test checklist

1. **Unauthenticated API**: open `/api/catalog` in a private window. It should return an authorization error, not catalog contents.
2. **Authorized login**: sign in with the Firebase user listed in `ADMIN_EMAILS`; categories and channels should load.
3. **Unauthorized Firebase user**: sign in with an account not in `ADMIN_EMAILS`. The API must reject catalog access and writes.
4. **Search**: search a channel name, logo URL, or stream URL.
5. **Preview**: existing logo URLs should display thumbnails when reachable.
6. **Channel edit**: edit a test channel, save, and confirm a new commit appears in the app repository. Check the exact TXT file and ensure the three-line record format remains intact.
7. **Channel delete/add**: test with a temporary branch first if possible.
8. **Android compatibility**: verify `Categories/categories.txt` still points to `https://raw.githubusercontent.com/vinod-rajput-vg/My-India-TV/main/Category%20Channels/<slug>.txt` and the Android app can refresh its catalog.
9. **Secrets check**: search the deployed page source and browser network responses; `GITHUB_TOKEN` and Firebase service-account private key must never appear.

## Adding a category safely

The Android app expects a channel TXT file to exist at `Category Channels/<slug>.txt` before the category is configured. Create that file in GitHub first (blank file is okay), then add the category in the panel with a public HTTP(S) icon URL. The panel writes the corresponding three-line entry to `Categories/categories.txt`. Removing a category removes only its entry from the category config; it intentionally leaves the channel TXT file as a backup.

## Security notes

- All write routes verify the Firebase ID token using Firebase Admin SDK and enforce the server-side `ADMIN_EMAILS` allowlist.
- GitHub token is used only in `lib/github.ts` on the server. Never rename it to `NEXT_PUBLIC_GITHUB_TOKEN`.
- Use a fine-grained token scoped to only this repository and Contents read/write.
- Firebase web API keys are not server secrets; restrict them in Firebase/Google Cloud where supported. The service-account private key and GitHub token are secrets.
- The panel validates channel URLs as HTTP(S) and restricts writes to known catalog paths. Stream URLs may still be unavailable or unauthorized; URL validation does not certify stream legality or playback.
- GitHub branch is `main` by default. Use a separate test branch by setting `GITHUB_BRANCH` during development if desired.

## Notes / limitations

- Category icon URL edits change only the category configuration; the image itself is not uploaded.
- New category files must be created in GitHub before the panel can add them. This avoids granting the panel arbitrary file-creation powers.
- Category deletion leaves the TXT file intact for recovery.
- This starter does not provide bulk import/export, audit UI, or automatic rollback. GitHub commit history is the recovery mechanism.
